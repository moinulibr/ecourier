	<div class="dropdown d-inline-block language-switch">
        <button type="button" class="btn header-item waves-effect" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img id="header-lang-img" src="{{asset('links/backend/01')}}/assets/images/flags/us.jpg" alt="Header Language" height="16">
        </button>
        <div class="dropdown-menu dropdown-menu-right">

            <!-- item-->
            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="eng">
                <img src="{{asset('links/backend/01')}}/assets/images/flags/us.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">English</span>
            </a>
            <!-- item-->
            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="sp">
                <img src="{{asset('links/backend/01')}}/assets/images/flags/spain.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Bangla</span>
            </a>
            
        </div>
	</div>
