<footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            <script>
                                document.write(new Date().getFullYear())
                            </script> © {{$websetting->company_name }}.
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Development By  <i data-feather="heart"></i> by <a href="https://www.softech.com.bd" target="_blank" class="text-reset">SOFTECHBD</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>