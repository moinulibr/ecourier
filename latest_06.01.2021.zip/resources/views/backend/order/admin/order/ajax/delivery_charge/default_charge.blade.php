<tr>
    <th>Cash Collections</th>
    <th>:</th>
    <td>Tk <span id="cash_collection_id">00.00</span></td>
</tr>
<tr>
    <th>Delivery Charge</th>
    <th>:</th>
    <td>Tk <span id="delivery_charge_id">00.00</span></td>
</tr>
<tr>
    <th>COD Charge</th>
    <th>:</th>
    <td>TK <span id="cod_charge_id">00.00</span></td>
</tr>
<tr>
    <th colspan="2">Total Payable Amount</th>
    <th><span>TK <strong id="total_payable_amount_id">00.00</strong> </span></th>
</tr>