<?php

namespace App\Model\Frontend;

use Illuminate\Database\Eloquent\Model;

class DeliveryMan extends Model
{
    //
}
