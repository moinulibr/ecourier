<?php

namespace App\Model\Backend\Order;

use Illuminate\Database\Eloquent\Model;

class Order_sms_sending extends Model
{
    //
}
