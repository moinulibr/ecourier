<?php

namespace App\Model\Backend\Order;

use Illuminate\Database\Eloquent\Model;

class Order_assigning_status extends Model
{
    //
}
