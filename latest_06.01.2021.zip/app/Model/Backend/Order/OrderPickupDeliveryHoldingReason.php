<?php

namespace App\Model\Backend\Order;

use Illuminate\Database\Eloquent\Model;

class OrderPickupDeliveryHoldingReason extends Model
{
    //
}
