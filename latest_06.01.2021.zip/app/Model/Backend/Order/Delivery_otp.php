<?php

namespace App\Model\Backend\Order;

use Illuminate\Database\Eloquent\Model;

class Delivery_otp extends Model
{
    //
}
