<?php

namespace App\Model\Backend\Order;

use Illuminate\Database\Eloquent\Model;

class OrderPickupDeliveryCancel extends Model
{
    //
}
