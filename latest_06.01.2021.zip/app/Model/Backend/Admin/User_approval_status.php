<?php

namespace App\Model\Backend\Admin;

use Illuminate\Database\Eloquent\Model;

class User_approval_status extends Model
{
    //
}
