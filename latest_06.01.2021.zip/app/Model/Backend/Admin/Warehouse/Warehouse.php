<?php

namespace App\Model\Backend\Admin\Warehouse;

use Illuminate\Database\Eloquent\Model;

class Warehouse extends Model
{
    //
}
