<?php

namespace App\Model\Backend\Admin\Warehouse;

use Illuminate\Database\Eloquent\Model;

class Parcel_in_warehouse extends Model
{
    //
}
