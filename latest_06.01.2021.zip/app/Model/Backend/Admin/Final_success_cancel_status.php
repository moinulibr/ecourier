<?php

namespace App\Model\Backend\Admin;

use Illuminate\Database\Eloquent\Model;

class Final_success_cancel_status extends Model
{
    //
}
