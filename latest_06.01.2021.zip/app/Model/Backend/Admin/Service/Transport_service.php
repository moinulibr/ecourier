<?php

namespace App\Model\Backend\Admin\Service;

use Illuminate\Database\Eloquent\Model;

class Transport_service extends Model
{
    //
}
