<?php

namespace App\Model\Backend\Admin\Service;

use Illuminate\Database\Eloquent\Model;

class Third_party_service extends Model
{
    //
}
