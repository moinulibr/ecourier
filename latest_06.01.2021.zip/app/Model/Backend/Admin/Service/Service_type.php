<?php

namespace App\Model\Backend\Admin\Service;

use Illuminate\Database\Eloquent\Model;

class Service_type extends Model
{
    protected $table = 'service_typies';
    
}
