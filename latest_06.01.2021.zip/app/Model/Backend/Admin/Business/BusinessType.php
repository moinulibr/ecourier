<?php

namespace App\Model\Backend\Admin\Business;

use Illuminate\Database\Eloquent\Model;

class BusinessType extends Model
{
    //
}
