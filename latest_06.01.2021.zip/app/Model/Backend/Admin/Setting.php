<?php

namespace App\Model\Backend\Admin;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    //
}
