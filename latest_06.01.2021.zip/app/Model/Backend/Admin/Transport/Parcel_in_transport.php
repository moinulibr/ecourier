<?php

namespace App\Model\Backend\Admin\Transport;

use Illuminate\Database\Eloquent\Model;

class Parcel_in_transport extends Model
{
    //
}
