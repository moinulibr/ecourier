<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class Parcel_category extends Model
{
    //
}
