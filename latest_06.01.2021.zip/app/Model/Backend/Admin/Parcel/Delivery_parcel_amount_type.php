<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class Delivery_parcel_amount_type extends Model
{
    //
}
