<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class Parcel_type extends Model
{
    protected $table = 'parcel_typies';
}
