<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class Parcel_owner_type extends Model
{
    //
}
