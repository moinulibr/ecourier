<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class Delivery_charge_type extends Model
{
    //
}
