<?php

namespace App\Model\Backend\Admin\Parcel;

use Illuminate\Database\Eloquent\Model;

class ParcelAmountPaymentType extends Model
{
    protected $table = "parcel_amount_payment_typies";
}
