<?php

namespace App\Model\Backend\Admin\Account;

use Illuminate\Database\Eloquent\Model;

class Bank_account extends Model
{
    //
}
