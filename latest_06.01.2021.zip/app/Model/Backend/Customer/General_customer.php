<?php

namespace App\Model\Backend\Customer;

use Illuminate\Database\Eloquent\Model;

class General_customer extends Model
{
    //
}
