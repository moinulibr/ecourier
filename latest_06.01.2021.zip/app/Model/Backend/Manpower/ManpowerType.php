<?php

namespace App\Model\Backend\Manpower;

use Illuminate\Database\Eloquent\Model;

class ManpowerType extends Model
{
    Protected $table = 'manpower_typies';
}
