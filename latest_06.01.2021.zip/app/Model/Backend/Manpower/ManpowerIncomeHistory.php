<?php

namespace App\Model\Backend\Manpower;

use Illuminate\Database\Eloquent\Model;

class ManpowerIncomeHistory extends Model
{
    //
}
