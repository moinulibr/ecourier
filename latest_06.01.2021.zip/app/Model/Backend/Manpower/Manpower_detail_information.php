<?php

namespace App\Model\Backend\Manpower;

use Illuminate\Database\Eloquent\Model;

class Manpower_detail_information extends Model
{
    //
}
