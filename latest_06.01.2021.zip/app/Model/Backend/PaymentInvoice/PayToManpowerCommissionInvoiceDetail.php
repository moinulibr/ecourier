<?php

namespace App\Model\Backend\PaymentInvoice;

use Illuminate\Database\Eloquent\Model;

class PayToManpowerCommissionInvoiceDetail extends Model
{
    //
}
