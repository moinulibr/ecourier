<?php

namespace App\Model\Backend\PaymentInvoice;

use Illuminate\Database\Eloquent\Model;

class PayToManpowerCommissionInvoice extends Model
{
    //
}
