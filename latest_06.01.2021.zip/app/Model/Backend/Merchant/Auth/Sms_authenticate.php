<?php

namespace App\Model\Backend\Merchant\Auth;

use Illuminate\Database\Eloquent\Model;

class Sms_authenticate extends Model
{
    //
}
