<?php

namespace App\Model\backend\Merchant\Setting;

use Illuminate\Database\Eloquent\Model;

class Merchant_Setting extends Model
{
    protected $table = "merchant_settings";
}
