<?php

namespace App\Model\Backend\Merchant\Setting;

use Illuminate\Database\Eloquent\Model;

class Merchant_setting extends Model
{
    //
}
