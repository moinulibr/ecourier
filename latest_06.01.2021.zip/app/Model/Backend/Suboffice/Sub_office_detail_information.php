<?php

namespace App\Model\Backend\Suboffice;

use Illuminate\Database\Eloquent\Model;

class Sub_office_detail_information extends Model
{
    //
}
