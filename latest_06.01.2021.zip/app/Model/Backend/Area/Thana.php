<?php

namespace App\Model\Backend\Area;

use Illuminate\Database\Eloquent\Model;

class Thana extends Model
{
    //
}
