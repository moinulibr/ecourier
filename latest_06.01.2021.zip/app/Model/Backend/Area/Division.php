<?php

namespace App\Model\Backend\Area;

use Illuminate\Database\Eloquent\Model;

class Division extends Model
{
    //
}
