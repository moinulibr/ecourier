<?php

namespace App\Model\Backend\Profit;

use Illuminate\Database\Eloquent\Model;

class Company_profit extends Model
{
    //
}
