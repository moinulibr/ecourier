<?php

namespace App\Model\Backend\Profit;

use Illuminate\Database\Eloquent\Model;

class Branch_profit extends Model
{
    //
}
