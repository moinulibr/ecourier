<?php

namespace App\Model\Backend\Agent;

use Illuminate\Database\Eloquent\Model;

class Agent_detail_information extends Model
{
    //
}
