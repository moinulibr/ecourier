<?php

namespace App\Model\Backend\Branch;

use Illuminate\Database\Eloquent\Model;

class Branch_type extends Model
{
    protected $table = "branch_typies";
}
