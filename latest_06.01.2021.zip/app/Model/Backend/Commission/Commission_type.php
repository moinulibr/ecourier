<?php

namespace App\Model\Backend\Commission;

use Illuminate\Database\Eloquent\Model;

class Commission_type extends Model
{
    //
}
