<?php

namespace App\Model\Backend\Commission;

use Illuminate\Database\Eloquent\Model;

class Manpower_commission_setting extends Model
{
    //
}
