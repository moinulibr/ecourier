<?php

namespace App\Model\Backend\ReceiveAmount;

use Illuminate\Database\Eloquent\Model;

class ReceiveAmountType extends Model
{
    //
}
