<?php

namespace App\Model\Backend\Hub;

use Illuminate\Database\Eloquent\Model;

class Hub_office_detail_information extends Model
{
    //
}
