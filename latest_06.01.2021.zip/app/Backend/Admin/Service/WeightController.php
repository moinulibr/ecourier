<?php

namespace App\Backend\Admin\Service;

use Illuminate\Database\Eloquent\Model;

class WeightController extends Model
{
    //
}
